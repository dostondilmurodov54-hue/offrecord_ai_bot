# Botni Render.com'da 24/7 ishga tushirish — to'liq qo'llanma

## Kerakli narsalar (oldindan tayyorlab qo'ying)
1. **Telegram TOKEN** — @BotFather'dan (`/newbot` orqali)
2. **Anthropic API KEY** — https://console.anthropic.com (API Keys bo'limi)
3. **GitHub akkaunt** — Render kodni GitHub orqali oladi
4. **Render.com akkaunt** — https://render.com (bepul, GitHub bilan kirish mumkin)

---

## 1-qadam: Kodni GitHub'ga joylash
1. https://github.com/new orqali yangi **repository** yarating (masalan: `mening-yordamchim-bot`)
2. Ushbu fayllarni o'sha repoga yuklang:
   - `main.py`
   - `requirements_render.txt`
   - `render.yaml`
   
   (Eng oson yo'l: GitHub sahifasida "Add file → Upload files" tugmasi orqali shu 3 ta faylni sudrab tashlang)

## 2-qadam: Render.com'da yangi xizmat yaratish
1. https://render.com ga kiring, GitHub akkauntingiz bilan ro'yxatdan o'ting
2. **New +** → **Blueprint** ni tanlang
3. Yuqorida yaratgan GitHub repongizni tanlang — Render `render.yaml` faylini o'zi topib, sozlamalarni avtomatik o'qiydi
4. **Environment Variables** bo'limida quyidagilarni kiriting:
   - `TELEGRAM_TOKEN` → BotFather'dan olgan tokeningiz
   - `ANTHROPIC_API_KEY` → Anthropic konsolidan olgan kalitingiz
5. **Apply** yoki **Create Web Service** tugmasini bosing

Render avtomatik ravishda kodni yuklab, ishga tushiradi (2-3 daqiqa vaqt oladi).
Loglarda `"Yordamchi ishga tushdi (Telegram polling)..."` degan yozuvni ko'rsangiz — tayyor!

## 3-qadam: Botni "uxlab qolishdan" saqlash (muhim!)
Render bepul rejasi 15 daqiqa faoliyatsizlikdan keyin xizmatni "uxlatib qo'yadi".
Buni oldini olish uchun bepul **UptimeRobot** xizmatidan foydalaning:

1. https://uptimerobot.com ga kiring (bepul ro'yxatdan o'ting)
2. **+ Add New Monitor** bosing
3. Monitor turi: **HTTP(s)**
4. URL manziliga Render bergan sizning xizmat manzilingizni kiriting
   (Render dashboardida yuqorida ko'rinadi, masalan: `https://mening-yordamchim-bot.onrender.com`)
5. Tekshirish oralig'ini **5 daqiqa** qilib qo'ying
6. Saqlang

Endi UptimeRobot har 5 daqiqada botingizga "salom" aytib turadi va u uxlab qolmaydi —
bot doim, 24/7 ishlab turadi.

---

## Tekshirib ko'rish
Telegramda botingizni toping va `/start` bosing. Javob kelsa — hammasi tayyor!

## Botning "xarakterini" o'zgartirish
Render dashboard → **Environment** bo'limiga kirib, `SYSTEM_PROMPT` nomli
yangi environment variable qo'shsangiz, botning qanday gapirishini
o'zingiz sozlashingiz mumkin.

## Muammo bo'lsa
- Render dashboard → **Logs** bo'limida xatolikni ko'rishingiz mumkin
- Eng ko'p uchraydigan xato: TOKEN yoki API_KEY noto'g'ri kiritilgan bo'ladi
