"""
Shaxsiy AI-yordamchi Telegram bot — Render.com uchun tayyor (1 fayl)
----------------------------------------------------------------------
Bu bot Claude API orqali ishlaydi va Telegramda shaxsiy yordamchi bo'lib xizmat qiladi.
Hech qanday login/parol so'ramaydi — foydalanuvchi shunchaki botga yozadi.

TOKEN va API_KEY endi shu faylda emas, balki Render.com'ning
"Environment Variables" bo'limida saqlanadi (xavfsizroq va Render shunday talab qiladi).
"""

import os
import logging
import threading

from flask import Flask
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)
from anthropic import Anthropic

# ============================================
# SOZLAMALAR — Render'da "Environment" bo'limidan olinadi
# ============================================
TELEGRAM_TOKEN = os.environ["TELEGRAM_TOKEN"]
ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]
ASSISTANT_NAME = os.environ.get("ASSISTANT_NAME", "Yordamchi")
SYSTEM_PROMPT = os.environ.get(
    "SYSTEM_PROMPT",
    "Sen foydalanuvchining shaxsiy yordamchisisan. Har doim samimiy, foydali "
    "va qisqa javob ber. Foydalanuvchi qaysi tilda yozsa, o'sha tilda javob ber "
    "(o'zbek, rus yoki ingliz). Kerak bo'lsa misollar keltir.",
)
PORT = int(os.environ.get("PORT", 10000))

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

client = Anthropic(api_key=ANTHROPIC_API_KEY)

user_histories: dict[int, list[dict]] = {}
MAX_HISTORY_MESSAGES = 20


# ---------- Telegram bot qismi ----------

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_histories[user_id] = []
    await update.message.reply_text(
        f"Salom! Men {ASSISTANT_NAME} — sizning shaxsiy yordamchingizman. "
        f"Menga istalgan savolingizni yozishingiz mumkin.\n\n"
        f"Buyruqlar:\n"
        f"/start — botni qayta ishga tushirish\n"
        f"/clear — suhbat tarixini tozalash"
    )


async def clear(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_histories[user_id] = []
    await update.message.reply_text("Suhbat tarixi tozalandi. Yangidan boshlaymiz!")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_text = update.message.text

    history = user_histories.setdefault(user_id, [])
    history.append({"role": "user", "content": user_text})
    trimmed_history = history[-MAX_HISTORY_MESSAGES:]

    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action="typing")

    try:
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1024,
            system=SYSTEM_PROMPT,
            messages=trimmed_history,
        )
        answer = "".join(block.text for block in response.content if block.type == "text")
    except Exception as e:
        logger.error(f"Anthropic API xatosi: {e}")
        answer = "Kechirasiz, hozir javob bera olmadim. Birozdan keyin qayta urinib ko'ring."

    history.append({"role": "assistant", "content": answer})
    user_histories[user_id] = history

    await update.message.reply_text(answer)


def run_bot():
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("clear", clear))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    logger.info(f"{ASSISTANT_NAME} ishga tushdi (Telegram polling)...")
    app.run_polling(stop_signals=None)


# ---------- Flask qismi (Render "web service" uchun kerak) ----------
# Render bepul rejasi doim ochiq PORT talab qiladi va uni vaqti-vaqti bilan
# "ping" qilib turadi (masalan UptimeRobot orqali) — shu tufayli bot uxlab qolmaydi.

web = Flask(__name__)


@web.route("/")
def health():
    return f"{ASSISTANT_NAME} ishlayapti ✅"


def run_web():
    web.run(host="0.0.0.0", port=PORT)


if __name__ == "__main__":
    # Telegram botni alohida thread'da, Flask serverni asosiy thread'da ishga tushiramiz
    bot_thread = threading.Thread(target=run_bot, daemon=True)
    bot_thread.start()
    run_web()
